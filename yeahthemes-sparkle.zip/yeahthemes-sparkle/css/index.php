<?php
/* Silent is golden */