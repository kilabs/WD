<?php
 // This file is not called from WordPress. We don't like that.
! defined( 'ABSPATH' ) and exit;
